<?php 
    $con = mysqli_connect("localhost", "root", "", "login_registration");

    if(!$con) {
        echo "<script>alert('Connection Failed')</script>";
    }
?>