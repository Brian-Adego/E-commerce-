<nav class="navbar navbar-expand-lg navbar-light bg-light container dflex justify-content-evenly">
			<button
				class="navbar-toggler"
				type="button"
				data-toggle="collapse"
				data-target="#navbarNavAltMarkup"
				aria-controls="navbarNavAltMarkup"
				aria-expanded="false"
				aria-label="Toggle navigation"
			>
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
				<div class="navbar-nav">
					<a class="nav-item nav-link active" href="#home"
						>Home <span class="sr-only">(current)</span></a
					>
					<a class="nav-item nav-link" href="#services">Services</a>
					<a class="nav-item nav-link" href="./buy.php">Buy</a>
					<a class="nav-item nav-link" href="./sell.php">Sell</a>
				</div>
			</div>
			
			<div class="navbar-nav">
			<?php
                $count = 0;
                if (isset($_SESSION['cart'])) {
                    $count = count($_SESSION['cart']);
                }
                ?>
				<a href="./mycart.php" class="btn btn-outline-success"><i class="fas fa-shopping-cart"><sup class="text-primary"><?php echo $count; ?></sup></i></a>
			</div>
			<div class="navbar-nav ml-5 p-2">
			<div class="dropdown">
				<button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
					<?php echo $_SESSION['username']; ?>
				</button>
				<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
					<li><a class="dropdown-item" href="/alcool/logout.php">Logout</a></li>
				</ul>
				</div>
			</div>
		</nav>