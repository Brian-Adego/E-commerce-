<?php
	$conn = mysqli_connect("localhost", "root", "", "login_registration");

	if(isset($_POST['submit'])) {
		$username = $_POST['username'];
		$mesg = $_POST['msg'];

		$sql = "INSERT INTO gmail (username, message) VALUES('$username', '$mesg')";

		if(mysqli_query($conn, $sql)) {
			
		} else {
			echo "<script>alert('Something went wrong')</script>";
		}
	}
?>

<footer class="mt-3 ml-3 col-sm-w-100 col-xs-w-100">
			<div class="container">
				<div class="row bg-info d-flex align-items-center p-3">
					<div class="col-sm d-flex flex-row">
						<i class="fas fa-shipping-fast mr-2"></i>
						<p class="text-dark font-weight-bold">Free Delivery and Return</p>
					</div>
					<div class="col-sm d-flex flex-row">
						<i class="fas fa-money-bill-wave-alt mr-2"></i>
						<p class="text-dark font-weight-bold">Money Guarantee</p>
					</div>
					<div class="col-sm d-flex flex-row">
						<i class="fas fa-wifi mr-2"></i>
						<p class="text-dark font-weight-bold">Online Support</p>
					</div>
				</div>
				<div class="row bg-dark text-white">
					<div class="col-sm fs-2 d-flex align-items-center fs">
						Email Address<br>alcool@alcool.ac.ke
						<br><br>
						Contact Number<br>+254721987564
					</div>
					<div class="col-sm p-5">
						<form action="" method="POST">
							<div class="form-group">
							  <label for="exampleFormControlInput1">Your email address</label>
							  <input type="email" name="username" class="form-control" id="exampleFormControlInput1" placeholder="name@domain.com">
							</div>
							<div class="form-group">
							  <label for="exampleFormControlTextarea1">Your Message</label>
							  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="msg"></textarea>
							</div>
							<button class="btn btn-primary btn-lg w-100" name="submit" value="submit">Send</button>
							</form>
					</div>
				</div>
			</div>
		</footer>
