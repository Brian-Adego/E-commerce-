<?php
    require("Connection.php");
    session_start();
    session_regenerate_id(true);
    if(!isset($_SESSION['AdminLoginId'])) {
        header("location: Admin Login.php");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Name</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" />
		<!-- css files -->
		<!-- script files-->
		<script src="./dist/JQUERY.min.js" defer></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" defer></script>
    <style>
        body {
            margin:0;
        }
        div.header {
            color:#f0f0f0;
            font-family:sans-serif;
            display:flex;
            flex-direction:row;
            align-items:center;
            justify-content:space-between;
            padding:20px 60px;
            background-color:#1c1c1e;
        }
        div.header button {
            background:#f0f0f0;
            font-size:16px;
            font-weight:550;
            padding:8px 12px;
            border:2px solid black;
            border-radius:5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>ADMIN PANEL - <?php echo $_SESSION['AdminLoginId'] ?></h1>
        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
        <button type="submit" name="Logout">LOGOUT</button>
        </form>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-sm">
                <table class="table table-dark mt-5">
                    <thead>
                        <tr>
                        <th scope="col">Order ID</th>
                        <th scope="col">Customer Name</th>
                        <th scope="col">Phone No</th>
                        <th scope="col">Address</th>
                        <th scope="col">Pay Mode</th>
                        <th scope="col">Orders</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $query = "SELECT * FROM `order_manager`";
                            $user_result = mysqli_query($con,$query);
                            while($user_fetch=mysqli_fetch_assoc($user_result)) {
                                echo "
                                <tr>
                                <th>$user_fetch[Order_Id]</th>
                                <td>$user_fetch[Full_Name]</td>
                                <td>$user_fetch[Phone_No]</td>
                                <td>$user_fetch[Address]</td>
                                <td>$user_fetch[Pay_Mode]</td>
                                <td>
                                <table class='table table-dark mt-5'>
                                <thead>
                                    <tr>
                                    <th scope='col'>Item Name</th>
                                    <th scope='col'>Price</th>
                                    <th scope='col'>Quantity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                ";
                                $order_query = "SELECT `Order_Id`, `Item_Name`, `Price`, `Quantity` FROM `user_orders` WHERE `Order_Id`='$user_fetch[Order_Id]'";
                                $order_result = mysqli_query($con,$order_query);
                                while($order_fetch=mysqli_fetch_assoc($order_result)) {
                                    echo "
                                    <tr>
                                        <td>$order_fetch[Item_Name]</td>
                                        <td>$order_fetch[Price]</td>
                                        <td>$order_fetch[Quantity]</td>
                                    </tr>";
                                }
                                    echo"
                                    </tbody>
                                    </table>
                                </td>
                                </tr>
                                ";
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>

<?php 
        if(isset($_POST['Logout'])) {
            session_destroy();
            header("location: Admin Login.php");
        }
    ?>