const navbar = document.querySelector(".navbar")
window.addEventListener("scroll", () => {
    const height = navbar.getBoundingClientRect().height;
    if (height<86) {
        navbar.style.position = "sticky";
        navbar.style.top = "0";
    }
});